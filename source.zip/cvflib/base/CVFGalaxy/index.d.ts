declare class CVFGalaxy {

}
export default CVFGalaxy