import { CVFElement } from "..";


export class CVFButton extends CVFElement {
  constructor(border) {
    super(border)

  }
  
}