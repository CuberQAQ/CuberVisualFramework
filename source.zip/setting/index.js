AppSettingsPage({
  build(props) {
    return Section({})
  },
})