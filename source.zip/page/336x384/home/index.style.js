import { gettext } from "i18n"

export const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT, screenShape } = hmSetting.getDeviceInfo()

