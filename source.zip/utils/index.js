export function assets(type) {
  return (path) => type + '/' + path
}